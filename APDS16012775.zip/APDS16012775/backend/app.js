//(n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).

const express = require('express');
const mongoose = require('mongoose');
const bodyparser = require('body-parser');
const fs = require('fs');
const orderRoutes = require("./routes/order");
const userRoutes = require("./routes/user");
const cors = require('cors');

const cert = fs.readFileSync('keys/certificate.pem');
const options ={
  server: {sslCA: cert}};

  const app = express();

app.use(express.json())
app.use(cors());
  mongoose.connect("mongodb+srv://16012775:<password>@apds7311task2-16012775.5serg.mongodb.net/APDS7311Task2-16012775?retryWrites=true&w=majority"
  , { useNewUrlParser: true, useUnifiedTopology: true })
.then(()=>
{
  console.log("Connection to DB : Successful")
})
.catch(()=>
{
  console.log('Connection to DB : Unsuccessful')
}, options);




app.use("/api/order",orderRoutes)
app.use("/api/user",userRoutes)
module.exports = app;
