//(n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).

const jwt = require('jsonwebtoken');
//function executed on incoming request.
module.exports=(req,res,next)=>
{
  try{
    console.log("I am in CheckAuthorization");
    const token = req.headers.authorization.split(" ")[1];
    jwt.verify(token,"secret_this_should_be_longer_time_is")
    console.log("Token Verified successfully");
    next();
  }
  catch(error)
  {
    res.status(401).json({
      message:"middleWare Autherization Failed - no valid token set"
    });
  }
}
