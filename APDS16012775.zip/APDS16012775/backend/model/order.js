//order model script
//exports the model schema for order/s
//model consists of users name; user email ; and the placed orders made by a user
//(n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).

const mongoose = require('mongoose');

const orderSchema = mongoose.Schema(
  {
    userName: {type: String, required:true},
    email:{type: String, required:true},
    placedOrder:{type:String, required:true}
  }

);

module.exports = mongoose.model('Order', orderSchema);
