//user model script
//exports the model schema for user/s
//model consists of users name; user email ; and the placed orders made by a user
//(n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).

const mongoose = require('mongoose');

const userSchem = mongoose.Schema(
  {
    userName: {type: String, required:true},
    email:{type:String, required:true},
    password:{type: String, required:true}
  }
);

module.exports = mongoose.model('User', userSchem);
