//(n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).

const express = require("express");

const router = express.Router();

const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const User = require('../model/user')
const ExpressBrute = require('express-brute');

const store = new ExpressBrute.MemoryStore();// stores state locally
const bruteforce = new ExpressBrute(store);


router.post("/signup",(req, res, next) =>{
  bcrypt.hash(req.body.password, 10, function(err, hash) {
    console.log(hash);
    const user = new User({
      username: req.body.username,
      email: req.body.email,
      password: hash
    });
    user.save().then((result) => {
      console.log(result);
    })
});
});

    router.post("/login", bruteforce.prevent, (req,res,next)=>{
      //creating global vriables to use in different code blocks.
      let fetchedUser;
      //checks if we have user with a valid e-mail address
      User.findOne({email: req.body.email})
      .then(user=>{
        fetchedUser = user;
        console.log("User found - " + user);
        if(!user)
        {
          return res.status(401).json(
            {
              message: "Authentication Failed - try again "

            });
        }
        // assigning retrieved user to global variable so we can use him later

        //compare hashed passwords ( always the same hash with same input)
        return bcrypt.compare(req.body.password,fetchedUser.password)//compare returned password and username in db
      })
      .then(result=>{
        console.log("User found");

        if(!result)
        {
          return res.status(401).json(
            {
              message: "Authentication Failed - try again"
            });
        }
        //create JWt if the user exists: JWT contains user e mail and user ID from
        //user object
        const token = jwt.sign({email:fetchedUser.email, userId:fetchedUser._id},
          'secret_this_should_be_longer_time_is',
          {
            expiresIn: '1h'
          });
          console.log("This token is generated in user.js " + token);
          res.status(200).json(
            {
              token:token
            });
      })
      .catch(err =>{
        console.log(err);
        return res.status(401).json({
          message:"Authentication Failed - try again"
        });
      })
    });


module.exports= router;
