//(n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).

const express = require("express");

const router = express.Router();

const Order = require('../model/order')
const CheckAuth = require('../middleware/check-auth');

router.post('',
CheckAuth,
//adding middle ware to check that a user is authenticated before they can create posts
(req,res,next)=>
{
  
console.log(req.body)
  const orders = new Order(
    {
      userName: req.body.id,
      email: req.body.userName,
      placedOrder: req.body.PlacedOrder
    }
  );
  //console.log(orders);
  orders.save()
  .then((createOrder)=>
  {
    console.log("Order has been saved in database");
    console.log(orders);
  res.status(201).json({
    message: "Order has been successfully created",
    orderID: createOrder._id
  });


  console.log(orders);
}).catch((err) => {
  console.log(err);
});

  });

router.get('',(req,res,next)=>
  {
    console.log("Orders GET");
    Order.find().then((documents)=>{
      res.status(200).json(
        {
          orders:documents
        });
    });
  });

  router.delete("/:id",
  //Check if the user has valid token using middle ware we created
  CheckAuth,
  (req,res,next)=>
  {
    console.log("Requested user delete --> " + req.params.id);
    Order.deleteOne({_id: req.params.id})
    .then((result)=>
    {
      //console.log(result);
      console.log("Order has been deleted from database");
      res.status(200).json({message: "Order has been deleted from database"});
    });
  });

  module.exports = router;
