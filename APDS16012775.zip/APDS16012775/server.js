const http = require('https');
const app = require('./backend/app');
const debug = require("debug")("node-angular");
const fs = require('fs');
const port = (process.env.PORT || "3000");
app.set("port", port);

//uses SSL certificates generated to validate the app
// (n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).
const server = http.createServer(
{
 key: fs.readFileSync('keys/privatekey.pem'),
 cert: fs.readFileSync('keys/certificate.pem')
},app);
server.listen(port, function(req, res){
  console.log("Server on " + port)
});