// (n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).
import { Component } from '@angular/core';
import { AuthService } from './Auth/AuthService';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'APDS7311-16012775';
  constructor( public AuthService: AuthService, private _router: Router){}
  onLogOut(){
    this.AuthService.Logout();
    this._router.navigate(['/login']);
    return false;

  }
}
