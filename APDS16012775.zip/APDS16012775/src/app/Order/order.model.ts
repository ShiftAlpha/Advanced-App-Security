// (n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).

export interface Order {
  id: string;
  userName: string;
  Email: string;
  PlacedOrder: string;
}
