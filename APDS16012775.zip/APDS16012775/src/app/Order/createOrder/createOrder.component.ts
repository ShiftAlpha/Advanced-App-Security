//(n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).

import { Component, Sanitizer, SecurityContext } from '@angular/core';
import { NgForm } from '@angular/forms';
import { OrdersService } from '../order.service';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { Order } from '../order.model';

@Component({
  selector: 'app-order-create',
  templateUrl: './createOrder.component.html',
  styleUrls: ['./createOrder.component.css'],
})
export class OrderCreateComponet {
  enteredUserNameError = 'Enter a user name in the correct form';
  enteredEmailError = 'Enter a correctly formatted e-mail address';
  enteredOrderError = '<b>Enter an order of no more than 50 characters</b>';
  output: string = '';
  output2: string = '';

  constructor(
    public orderService: OrdersService,
    public route: ActivatedRoute,
    protected sanitizer: DomSanitizer
  ) {}

  onAddOrder(one: string, two: string, three: string, four: string) {
    if (one === null || two === null || three === null) {
      return;
    }

    let order: Order = {
      id: one,
      userName: two,
      Email: three,
      PlacedOrder: four,
    };

    this.orderService.addOrders(one, two, three, four);
    this.output = String(this.sanitizer.sanitize(SecurityContext.HTML, order));
  }
}
