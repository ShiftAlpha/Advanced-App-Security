//(n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).

import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Order } from '../order.model';
import { OrdersService } from '../order.service';

@Component({
  selector: 'app-order-placed',
  templateUrl: './order-placed.component.html',
  styleUrls: ['./order-placed.component.css'],
})
export class OrderPlacedComponent implements OnInit, OnDestroy {
  orders: Order[] = [];
  ordersSubscription = new Subscription();
  constructor(public orderService: OrdersService) {}

  //create instance of subscription
  ngOnInit() {
    this.orderService.getOrders();
    this.ordersSubscription = this.orderService
      .getPostUpdateListener()
      .subscribe((orders) => {
        this.orders = orders;
      });

    console.log(this.orders.length);
  }
  ngOnDestroy() {
    this.ordersSubscription.unsubscribe();
  }
  btndlt(orderID: string) {
    console.log(orderID);
  }
  posts: { userName: string; orderDetails: string; enteredEmail: string }[] =
    [];
}
