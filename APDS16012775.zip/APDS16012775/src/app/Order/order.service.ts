// (n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).
import { Injectable } from '@angular/core';
import { identity, Subject } from 'rxjs';
import { Order } from './order.model';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Identifiers } from '@angular/compiler';

@Injectable({ providedIn: 'root' })
export class OrdersService {
  constructor(private http: HttpClient) {}
  private orders: Order[] = [];
  private updatedOrders = new Subject<Order[]>();

  getOrders() {
    this.http
      .get<{ orders: any }>('https://localhost:3000/api/orders')
      .pipe(
        map((orderData: any) => {
          return orderData.orders.map((d: any) => {
            return {
              id: d._id,
              userName: d.userName,
              Email: d.Email,
              PlacedOrder: d.PlacedOrder,
            };
          });
        })
      )
      .subscribe((changedOrders) => {
        this.orders = changedOrders;
        this.updatedOrders.next([...this.orders]);
      });
  }
  getPostUpdateListener() {
    return this.updatedOrders.asObservable();
  }

  addOrders(_id: string, userName: string, Email: string, PlacedOrder: string) {
    const order: Order = {
      id: _id,
      userName: userName,
      Email: Email,
      PlacedOrder: PlacedOrder,
    };
    this.http
      .post<{ message: string; orderId: string }>(
        'https://localhost:3000/api/orders',
        order
      )
      .subscribe((responseOrderData) => {
        console.log(responseOrderData.message);
        const id = responseOrderData.orderId;
        order.id = id;
        this.orders.push(order);
        this.updatedOrders.next([...this.orders]);
      });
  }
  deleteOrder(id: string) {
    this.http
      .delete('https://localhost:3000/api/orders' + id)
      .subscribe(function (orderID) {
        console.log('Order Deleted');
      });
  }
}
