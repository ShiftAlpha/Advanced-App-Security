//This script handles all the auth methods for users creating a profile, logging in, validation & auth of logout
// (n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';

import { AuthData } from './AuthData.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private token: any;

  constructor(private http: HttpClient, private _router: Router) {}

  getToken() {
    return this.token;
  }
  createUser(email: string, password: string, username: string) {
    const authData: AuthData = {
      email: email,
      password: password,
      username: username,
    };

    this.http
      .post('https://localhost:3000/api/user/Register', authData)
      .subscribe((response) => {
        console.log(response);
        this._router.navigate(['/login']);
      });
  }
  login(email: string, password: string, username: string) {
    const authData: AuthData = {
      email: email,
      password: password,
      username: username,
    };
    console.log('Login() in Auth-Service');
    this.http
      .post<{ token: string }>(
        'https://localhost:3000/api/user/Login',
        authData
      )
      .subscribe((response) => {
        const token = response.token;
        this.token = token;
        localStorage.setItem('token', this.token);
        console.log('This is my token --> ' + response);
        this._router.navigate(['/create']);
      });
  }
  loggedIn() {
    return !!localStorage.getItem('token');
  }

  Logout() {
    this.token = null;
    localStorage.clear();
  }
}
