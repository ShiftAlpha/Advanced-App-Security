//typescript component to handle all functionality of the register function

//imports
import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
//imports AuthService in order to call the AuthService methods, for validation of registration
import { AuthService } from '../AuthService';

@Component({
  templateUrl: '../Register/RegisterFunction.component.html',
})
export class RegisterComponent {
  constructor(public services: AuthService) {}

  enteredUserNameError = 'Please enter a user name in the correct form';
  enteredEmailError = 'please enter a correctly formatted e-mail address';
  enteredOrderError = 'please enter an order of no more than 50 characters';
  enteredPasswordError =
    'Please enter a password that conatins lower case,' +
    'upper case letter and at least one number';
  isLoading = 'false';

  onSignup(form: NgForm) {
    console.log(
      form.value.enteredEmail +
        '\n' +
        form.value.enteredUserName +
        '\n' +
        form.value.enteredPassword
    );
    this.services.createUser(
      form.value.enteredEmail,
      form.value.enteredPassword,
      form.value.enteredUserName
    );
  }
}
