//exporr file
//exports the user AuthData
// (n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).
export interface AuthData {
  username: string;
  email: string;
  password: string;
}
