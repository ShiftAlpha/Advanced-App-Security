//typescript component for the login function
//tyepscript functionality occurs behind the html displayed component

//imports
import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

//imports AuthService to call authentication functionality and methods. This is for user validation
import { AuthService } from '../AuthService';

@Component({
  templateUrl: './loginFunction.component.html',
})
export class LoginComponent {
  enteredUserNameError = 'Enter a user name in the correct form';
  enteredEmailError = 'Enter a correctly formatted e-mail address';
  enteredOrderError = 'Enter an order of no more than 50 characters';
  enteredPasswordError =
    'Enter a password that conatins lower case,' +
    'upper case letter and at least one number';

  constructor(public authService: AuthService) {}

  onLogin(form: NgForm) {
    if (form.invalid) {
      alert('mesage');
    } else {
      this.authService.login(
        form.value.enteredEmail,
        form.value.enteredPassword,
        form.value.enteredUsername
      );

      console.log(form.value);
    }
  }
}
