// typescript component that handles the functionality of the html output

//imports of angular core
//imports of angular material
//all added to package-lock ; package ; angular.json
// (n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  templateUrl: './errorHandling.component.html',
})
export class ErrorComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: { message: string }) {}
}
