// (n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular//material/Input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDialogModule } from '@angular/material/dialog';
import { OrderCreateComponet } from './Order/createOrder/createOrder.component';
import { OrderPlacedComponent } from './Order/placedOrder/placedOrder.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginComponent } from './Auth/Login/loginFunction.component';
import {ErrorComponent} from './Auth/ErrorHandling/errorHandling.component'
import { SignUpComponent } from './Auth/Register/RegisterFunction.component';
import { AuthInterceptor } from './Auth/AuthInterceptor';
import { ErrorInterceptor } from './Auth/ErrorInterceptor.component';


@NgModule({
  declarations: [
    AppComponent,
    OrderCreateComponet,
    OrderPlacedComponent,
    LoginComponent,
    SignUpComponent,
    ErrorComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatExpansionModule,
    HttpClientModule,
    MatDialogModule
  ],
  providers: [{provide:HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true},
  {provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi:true}],
  bootstrap: [AppComponent],
  entryComponents: [ErrorComponent]
})
export class AppModule { }
