// (n.d.) 'APDS7311 LAB Guide: Part A', , (), pp. [Online]. Available at: (Accessed: 15 May 2021).
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderPlacedComponent } from './Order/placedOrder/placedOrder.component';
import { OrderCreateComponet } from './Order/createOrder/createOrder.component';
import { LoginComponent } from './Auth/Login/loginFunction.component';
import { SignUpComponent } from './Auth/Register/RegisterFunction.component';
const routes: Routes = [
  { path: '', component: OrderPlacedComponent },
  { path: 'create', component: OrderCreateComponet },
  { path: 'edit/:postId', component: OrderCreateComponet },
  { path: 'Login', component: LoginComponent },
  { path: 'Register', component: SignUpComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
